package com.cice.microserviciofeign.gestionproductos.service;

import com.cice.microserviciofeign.gestionproductos.entity.Producto;
import com.cice.microserviciofeign.gestionproductos.repository.ProductoRepository;
import com.cice.microserviciofeign.gestionproductos.rest.dto.ProductoDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class GestionProducto implements IGestionProducto{

    @Autowired
    ProductoRepository productoRepository;

    @Override
    public List<ProductoDTO> getAllProductos() {
        List<ProductoDTO> collect = productoRepository.findAll()
                .stream()
                .map(
                        productoentity -> new ProductoDTO(
                                productoentity.getId(),
                                productoentity.getIdUsuario(),
                                productoentity.getNombre(),
                                productoentity.getCodigo(),
                                productoentity.getPrecio()
                        )
                ).collect(Collectors.toList());
        return collect;
    }

    @Override
    public List<ProductoDTO> getProductoByIdUsuario(Long idUsuario) {
        List<ProductoDTO> collect = productoRepository.findByIdUsuario(idUsuario)
                .stream()
                .map(productoentity -> new ProductoDTO(
                                productoentity.getId(),
                                productoentity.getIdUsuario(),
                                productoentity.getNombre(),
                                productoentity.getCodigo(),
                                productoentity.getPrecio()
                        )
                ).collect(Collectors.toList());
        return collect ;
    }

    @Override
    public ProductoDTO crearProductoByUsuario(Long idUsuario, ProductoDTO productoDTO) {
        Producto producto = new Producto(
                null,
                idUsuario,
                productoDTO.getNombre(),
                productoDTO.getCodigo(),
                productoDTO.getPrecio()
        );
        Producto resultado = productoRepository.save(producto);
        return new ProductoDTO(
                resultado.getId(),
                resultado.getIdUsuario(),
                resultado.getNombre(),
                resultado.getCodigo(),
                resultado.getPrecio()
        );
    }

    @Override
    public List<ProductoDTO> eliminarProductosByUsuario(Long idUsuario) {
        List<Producto> productosObjetivo = productoRepository.findByIdUsuario(idUsuario);
        productoRepository.deleteByidUsuario(idUsuario);
        List<ProductoDTO> collect = productosObjetivo.stream()
                .map(producto -> new ProductoDTO(
                                producto.getId(),
                                producto.getIdUsuario(),
                                producto.getNombre(),
                                producto.getCodigo(),
                                producto.getPrecio()
                        )
                ).collect(Collectors.toList());
        return collect;
    }
}
