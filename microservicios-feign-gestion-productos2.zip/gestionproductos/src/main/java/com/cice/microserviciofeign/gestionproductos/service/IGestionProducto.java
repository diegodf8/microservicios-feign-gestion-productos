package com.cice.microserviciofeign.gestionproductos.service;

import com.cice.microserviciofeign.gestionproductos.rest.dto.ProductoDTO;

import java.util.List;

public interface IGestionProducto {

    List<ProductoDTO> getAllProductos();
    List<ProductoDTO> getProductoByIdUsuario(Long idUsuario);
    ProductoDTO crearProductoByUsuario(Long idUsuario, ProductoDTO productoDTO);
    List<ProductoDTO> eliminarProductosByUsuario(Long idUsuario);

}
