package com.cice.microserviciofeign.gestionproductos.repository;

import com.cice.microserviciofeign.gestionproductos.entity.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long> {

    List<Producto> findByIdUsuario(Long idUsuario);
    @Transactional
    void deleteByidUsuario(Long idUsuario);
}
